library(testthat)
library(GA)

test_check("GA")
